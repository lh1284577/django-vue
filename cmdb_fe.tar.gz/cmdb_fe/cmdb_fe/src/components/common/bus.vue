<!--
* Author: 宋翔
* Email: songxiang@bizwell.cn
* Company: 百味云科技股份有限公司
-->
<template>
</template>

<script>
    import Vue from 'vue'
    export default new Vue()
</script>
