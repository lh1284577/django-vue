<template>
  <div class="phone-viewport">
      <form   style="margin:50px 50px 0px 0px">

        <mu-flexbox >
            <mu-flexbox-item align="center">
                <h2 >批量分发</h2>
            </mu-flexbox-item>
        </mu-flexbox>
      <md-whiteframe md-elevation="1">

        <mu-flexbox style="margin:40px 40px 0px 0px">
            <mu-flexbox-item >
                <div >
                    <table  class="infoTable" style="text-align:right;width:80%;margin:40px 40px 0px 0px">
                        <tbody>
                        <tr>
                            <td></td>
                            <td>
                                <md-button-toggle md-single class="md-primary">
                                <md-button @click.native="openfiledailog" class="">服务器文件
                                </md-button>

                                <md-button @click.native="openrsyncfiledailog" class="md-toggle">本地上传文件
                                </md-button>
                                </md-button-toggle>
                            </td>
                        </tr>
                        <tr>
                            <th>文件来源:</th>
                            <td style="width:80%;text-align:left" >
                                <vue-dropzone v-if="rsyncfiledailog" ref="myVueDropzone" id="dropzone" :options="dropzoneOptions" @vdropzone-success="uploaded" @vdropzone-error="onFileError" ></vue-dropzone>
                                <md-input-container v-if="localfiledailog">
                                    <md-input placeholder="例: /tmp/1.txt"   v-model="linuxfile"></md-input>
                                </md-input-container>
                                
                            </td>
                        </tr>
                        <tr>
                            <th></th>
                            <td style="width:80%;text-align:left" >
                                <md-whiteframe v-if="localfiledailog" md-elevation="1" style="padding: 0em 0.5em 0.5em 1em;height:400px; overflow-y: auto; background: #333; color: #FFF;">
                                        <md-card-content >
                                            <pre>
                                                <table v-for="(item,index) in dirlist" :key="index">
                                                <tr >{{item}}</tr>
                                                </table>
                                            </pre>
                                        </md-card-content>
                                </md-whiteframe>
                            </td>
                        </tr>
                        <tr v-if="contacts.length != 0 && rsyncfiledailog">
                            <td></td>
                            <td>
                                <md-chips  v-model="contacts" ></md-chips>
                            </td>
                        </tr>
                        <tr>
                            <th>执行用户:</th>
                            <td>
                                <md-input-container >
                                    <md-input v-model="deploylist.user"></md-input>
                                </md-input-container>
                            </td>
                        </tr>
                        <tr>
                            <th><md-button class="md-primary md-raised" id="custom" @click.native="openDialog('dialog1')">选择服务器</md-button></th>
                            <td>
                                <div style="float:left">
                                    <div>


                    <md-whiteframe  md-elevation="2" style="width:600px;">
                        <md-table>
                            <md-table-header>
                                <md-table-row>
                                    <md-table-head md-numeric>服务器</md-table-head>
                                    <md-table-head md-numeric>上传进度</md-table-head>
                                    <md-table-head md-numeric>状态</md-table-head>
                                </md-table-row>
                            </md-table-header>
                            <md-table-body>
                                <md-table-row v-for="(item,index) in selectip" :key="index">
                                <md-table-cell >{{item}}</md-table-cell>
                                <md-table-cell >
                                    <mu-linear-progress mode="determinate" :size="10" :color="grogress[item]? grogress[item].color: ''" :value="grogress[item]? grogress[item].progress: 0" />
                                    {{grogress[item]? grogress[item].percent:''}}
                                </md-table-cell>
                                
                                <md-table-cell >{{grogress[item]? uploadstatus[grogress[item].status] : '未执行'}}</md-table-cell>
                                </md-table-row>
                            </md-table-body>
                        </md-table>

                        <div v-if="selectip.length === 0" style="text-align: center;">
                            <img :src="`/static/nothing.jpg`" style="margin: 2em; height: 10em"/>
                            <div style="padding: 1em;color:#dd4b39"><md-icon>info</md-icon> 没有东西</div>
                        </div>
                    </md-whiteframe>

                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th>目标路径:</th>
                            <td>
                                <md-input-container>
                                    <md-textarea v-model="deploylist.desc"></md-textarea>
                                </md-input-container>
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>
                                <p v-if="deploylist.desc.length !=0" style="float:left;color:red">注意: 确认目标服务器是否存在此目录</p>
                                <md-button class="md-primary md-raised" id="custom" :disabled="selectip.length === 0" @click.native="deploy()">开始执行</md-button>
                            </td>
                        </tr>
                        </tbody>
                        
                    </table>
                </div>
            </mu-flexbox-item>
        </mu-flexbox>
      </md-whiteframe>
      </form>

    <md-dialog md-open-from="#custom" md-close-to="#custom" ref="dialog1">

        <md-dialog-content>
            <idclist ref="idclist" @selectform="getuser">
            </idclist>
        </md-dialog-content>

        <md-dialog-actions>
            <md-button class="md-primary" @click.native="closetrueDialog('dialog1')">确认</md-button>
        </md-dialog-actions>
    </md-dialog>





        <md-snackbar md-position="top center" ref="snackbar" md-duration="3000">
            <div>
                <md-icon >error</md-icon>
                <span>{{error}}</span>
            </div>
        </md-snackbar>

  </div>
  
</template>

<script>
/* eslint-disable */
import idclist from './idclist'
import vue2Dropzone from 'vue2-dropzone'
import 'vue2-dropzone/dist/vue2Dropzone.css'

const toLower = text => {
return text.toString().toLowerCase()
}

const searchByName = (items, term) => {
if (term) {
    var str = term.split('/')
    term = str[str.length-1]
    return items.filter(item => toLower(JSON.stringify(item)).includes(toLower(term)))
}

return items
}


export default {
    data() {
        return {
            selectip: '',
            grogress:{
            },
            output: '',
            deployLoading: false,
            fristactive: true,
            contacts: [],
            dirlist: [],
            linuxfile: '',
            localfiledailog: false,
            rsyncfiledailog: true,
            error: '',
            uploadstatus: {
                '-1': '未执行',
                '0': '正在执行',
                '1': '执行成功',
                '2': '执行失败',
                },
            errortype: {
                1:'上传文件大小超过限制',
                2:'上传文件不能为空'
            },
            outstatus: {
                color:'gray',
                fontSize: '1.4em',
                des: '未执行',
                ops: '执行构建'
            },
            deploylist: {
                user: 'root',
                desc: '/opt',
            },
            dropzoneOptions: {
                url: 'http://test.com/yunwei/api/upload',
                thumbnailWidth: 150,
                maxFilesize: 0.001,
            },
        }
    },
    watch: {
        linuxfile (val) {
            if (val.charAt(val.length-1) === '/') {
                var output = this.lsdir(val)
            }
            else if (val.length === 0 ) {
                this.dirlist = ''
            }
            this.dirlist = searchByName(this.dirlist, val)
        }
    },
    updated() {
        var ele = document.getElementById('deploylog')
        if (ele) {
            ele.scrollTop = ele.scrollHeight
        }
    },
    methods: {

        searchOnTable (item) {
            this.dirlist = searchByName(this.dirlist, item)
        },
        openfiledailog() {
            this.localfiledailog = true
            this.rsyncfiledailog = false
            this.contacts = []
        },
        openrsyncfiledailog() {
            this.localfiledailog = false
            this.rsyncfiledailog = true
            this.dirlist = ''
            this.linuxfile = ''
        },
        openDialog(ref) {
            this.$refs.dialog1.open();
        },
        closetrueDialog(ref) {
            this.$refs.dialog1.close();
        },
        getuser(item) {
            this.selectip = item.map(item => item.ip)
            this.uploaddailog = true
        },
        uploaded (file, response) {
            this.$refs.myVueDropzone.removeAllFiles()
            this.contacts.push(file.name)
        },
        onFileError () {
            this.error = this.errortype[1]
            this.$refs.snackbar.open()
        },
        deploy () {
            if (this.linuxfile.length === 0 && this.contacts.length === 0) {
                this.error = this.errortype[2]
                this.$refs.snackbar.open()
                return
            }
            var form = {
                    'iplist':JSON.stringify(this.selectip),
                    'filelist': JSON.stringify(this.contacts),
                    'localfilelist': JSON.stringify(this.linuxfile),
                    'des': this.deploylist.desc,
                    'user': this.deploylist.user
            }
            var url = 'http://test.com/yunwei/api/rsyncFile'
            this.$http.post(url,form).then(response => {
                if (response.data.code === 0) {
                    this.output = this.deployResult()
                }
                else if (response.data.code === 400) {
                    this.error = response.data.msg
                    this.$refs.snackbar.open()
                }
            })
        },
        deployResult () {
            var form = {
                    'iplist':JSON.stringify(this.selectip),
            }
            var url = 'http://test.com/yunwei/api/rsyncFileResoult'
            this.$http.post(url,form).then(response => {
                if (response.data.ok != false) {
                    this.grogress = response.data.msg
                }
                var count = 0
                for (var i in this.grogress) {
                    if (response.data.msg[i].progress === 999){
                        this.grogress[i].status = '2'   
                        this.grogress[i].color = 'red'
                        this.grogress[i].percent = '0%'
                    }
                    else if (response.data.msg[i].progress != 100){
                        count=1
                        this.grogress[i].status = '0'
                        this.grogress[i].color = 'yellow'
                        this.grogress[i].percent = response.data.msg[i].progress + '%'
                    }
                    else if (response.data.msg[i].progress === 100){
                        this.grogress[i].status = '1'
                        this.grogress[i].color = 'green'
                        this.grogress[i].percent = response.data.msg[i].progress + '%'
                    }
                    else {
                        this.grogress[i].status = '0'
                    }
                }
                if ( count === 0){
                    return
                }

                window.setTimeout(() => {
                this.deployResult()
                }, 2000)
            })
        },
        lsdir(resoult) {
            this.$http.get('http://test.com/yunwei/api/lsDir',
            {
                params: {
                    dir:this.linuxfile,
                }
            } 
            ).then(response => {
                if (response.data.ok != false) {
                    this.dirlist = response.data.msg
                }
            })
        }
    },
    components: {
        idclist,
        vueDropzone: vue2Dropzone
    }
}
</script>


<style>
 /* .md-input-placeholder {
     height: 48px;
 } */
</style>

