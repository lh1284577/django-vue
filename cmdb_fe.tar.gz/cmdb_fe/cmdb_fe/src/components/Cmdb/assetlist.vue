<template>
  <div>
      <component :is="assetListType[$route.params.assetType]" ></component>
  </div>
</template>

<script>
/* eslint-disable */

  import idclist from './asset/idclist'
  import opslist from './asset/opslist'
  import distribution from './asset/distribution'
  export default {
    data () {
      return {
        assetListType: {
          'idc': 'idclist',
          'ops': 'opslist',
	  'distribution': 'distribution'
        },
        loading: true
      }
    },
    mounted () {
    },
    created () {
    },
    methods: {
    },
    components: {
      idclist,
      opslist,
      distribution
    }
  }
</script>
